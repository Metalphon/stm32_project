//#ifndef __OV5640_DCMI_H
//#define __OV5640_DCMI_H
//
//#include "main.h"
//
//void atk_mc5640_dcmi_init(void);
//void atk_mc5640_dcmi_start(uint32_t dts_addr,  uint32_t len);
//
//#endif

