# STM32_camera
STM32H7 ov5640实现图像采集和传输
