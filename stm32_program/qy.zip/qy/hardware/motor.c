#include "motor.h"
#include "stm32h7xx.h"                  // Device header


uint16_t speed;

void sportfront(uint16_t speed)
{
	
}

void sportback(uint16_t speed)
{
	
}

void sportright(uint16_t speed)
{

}

void sportleft(uint16_t speed)
{

}

void sportstop()
{

}

void qyup()
{

}

void qyright()
{

}

void qyleft()
{

}

void qy_off()
{

}

void qydown()
{

}

void qyfront()	
{

}

void qyback()
{

}

void speed_low()
{
speed=30;
}

void speed_middle()
{
speed=60;
}

void speed_hight()	
{
speed=90;
}
	
