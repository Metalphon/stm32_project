#ifndef _pwm_H
#define _pwm_H

#include "System.h"
void TIM4_CH1_PWM_Init(u16 arr,u16 psc);
void TIM2_PWM_Init(u32 arr,u32 psc);
void TIM3_PWM_Init(u32 arr,u32 psc);
#endif


