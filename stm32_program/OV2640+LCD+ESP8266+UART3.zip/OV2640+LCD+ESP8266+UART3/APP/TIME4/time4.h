#ifndef _time4_H
#define _time4_H

#include "System.h"

void TIM4_Init(u16 per,u16 psc);

#endif


