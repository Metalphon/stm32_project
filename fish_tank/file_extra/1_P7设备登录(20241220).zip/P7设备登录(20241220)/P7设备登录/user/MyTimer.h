#ifndef __TIMER_H
#define __TIMER_H
extern u8 Num;
void Timer4_Init(void);

#endif
