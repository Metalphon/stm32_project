#ifndef _TIM2_H_
#define _TIM2_H_


//extern unsigned short timeCount = 0;

void TIM2_Configuration(void);

void NVIC_Configuration(void);

void TIM2_Iint(void);



#endif
