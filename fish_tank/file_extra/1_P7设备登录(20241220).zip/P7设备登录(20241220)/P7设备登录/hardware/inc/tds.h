#ifndef TDS_H
#define TDS_H

float TDS_Value_Conversion(void);

#endif
