#ifndef NTU_H
#define NTU_H

float TU_Value_Conversion(void);

#endif
