<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
page {
	   background-image:url('././static/2.jpg'); /* 替换为你实际的背景图片路径 */
	     
	}

</style>
